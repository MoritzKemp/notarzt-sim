#include "SimObject.h"

SimObject::SimObject()
{
    //ctor
}

SimObject::~SimObject()
{
    //dtor
}



