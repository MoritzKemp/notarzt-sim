#include "NotarztPlace.h"

NotarztPlace::NotarztPlace()
{
    //ctor
}

NotarztPlace::~NotarztPlace()
{
    //dtor
}
