enum class NotarztStates
{
    // Notarzt
    WARTEND,
    UNTERWEGS_PATIENT,
    UNTERWEGS_ZENTRALE,
    BEHANDLUNG
};
